The files being distributed here are

tar.R
Replicates the empirical work reported in "Inference when a 
nuisance parameter is not identified under the null hypothesis."

tar.R
R procedure to calculate TAR test.

star.R
R procedure to calculate STAR test.

gnp.dat
Contains the data.

If you have questions, please contact me at:

Bruce E. Hansen
Department of Economics
Social Science Building
University of Wisconsin
Madison, WI 53706-1393
behansen@wisc.edu
http://www.ssc.wisc.edu/~bhansen/
