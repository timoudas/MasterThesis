The following files are distributed in connection with

"Testing for Linearity" by Bruce E. Hansen.

For updates and contact information, see my webpage
www.ssc.wisc.edu/~bhansen

sunspot.dat	      sunspot data
sunspot.R	      F_12 test program
sunspot2.R	      F_13 test program
sunspot3.R	      F_23 test program
ip.dat            industrial production data
ip.R		      F_12 test program
ip2.R		      F_13 test program
ip3.R	    	      F_23 test program
plot.R            program which makes the graphs



