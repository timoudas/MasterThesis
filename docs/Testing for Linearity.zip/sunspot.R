##  SUNSPOT.R 
##
##  This replicates some of the empirical work reported in 
##  "Testing for Linearity" by Bruce E. Hansen.
##  For updates and contact information, see my webpage
##  www.ssc.wisc.edu/~bhansen
## 
## 
##  This program estimates a two-regime TAR model, and tests the null of a 
##  one-regime AR against the alternative of a two-regime TAR 
##
###########################################################################

dat <- read.table("sunspot.dat")
yname <- "Sunspots"	   # name of series 
dat <- (sqrt(1+dat)-1)*2   # load and define univariate series 
p <- 11		# order of autoregression 
dmin <- 1		# minimal delay order 
dmax <- p		# maximal delay order (set to p or less 
trim <- .1		# minimal percentage of data per regime 
qnum <- 100	      # Number of thresholds to search. 
                  # Set _qnum=0 to search over all values 
boot <- 1000	# bootstrap replications 

###########################################################################

# Define Data #
n <- nrow(dat)
y <- as.matrix(dat[(p+1):n,])
t <- n-p
x <- cbind(matrix(1,t,1),dat[p:(n-1),])
xname <- rbind("Constant","Y(t-01) ")
xname2 <- rbind("Constant","Y(t-01)^2 ")
for (j in 2:p){
    x <- cbind(x,dat[(p+1-j):(n-j),]) 
    if (j<10){ pn <- paste(c("0"),j,sep="")
    }else{ pn <- as.character(j)}
    namej <- paste(c("Y(t-"),pn,c(")"),sep="")
    xname <- rbind(xname,namej)
    xname2 <- rbind(xname2,paste(namej,c("^2"),sep=""))
}
k <- ncol(x)

# Linear Regression #
mi <- solve(t(x)%*%x)
beta <- mi%*%(t(x)%*%y)
e <- y-x%*%beta
ee <- t(e)%*%e
xe <- x*(e%*%matrix(1,1,ncol(x)))
sig <- ee/t
xee <- t(xe)%*%xe
se <- as.matrix(sqrt(diag(mi%*%xee%*%mi)))

# Conditional Variance #
e2 <- e^2
x2 <- x^2
m2 <- solve(t(x2)%*%x2)
hetbeta <- m2%*%(t(x2)%*%e2)
h <- x2%*%hetbeta
eh <- e/sqrt(h*(h>0)+(h<=0))*(h>0)
u <- e2-h
x2u <- x2*(u%*%matrix(1,1,ncol(x2)))
x2u <- t(x2u)%*%x2u
se2 <- as.matrix(sqrt(diag(m2%*%x2u%*%m2)))
em <- e2-mean(e2)
fh <- t*((t(em)%*%em)/(t(u)%*%u)-1)

# Report Linear Estimation #
for (i in 1:1){
cat ("Dependent Variable:     ", yname, "\n")
cat ("\n")
cat ("Linear Autoregression", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
xname <- format(xname,digits=4)
tbeta <- format(beta,digits=4)
tse <- format(se,digits=4)
for (j in 1:nrow(beta)) cat (xname[j],"  ",tbeta[j],"  ",tse[j],"\n")
cat ("\n")
cat ("Observations                      ", t, "\n")
cat ("Sum of Squared Errors             ", ee, "\n")
cat ("Residual Variance                 ", sig, "\n")
cat ("\n")
cat ("\n")
cat ("Conditional Variance", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
xname2 <- format(xname2,digits=4)
thetbeta <- format(hetbeta,digits=4)
tse2 <- format(se2,digits=4)
for (j in 1:nrow(beta)) cat (xname2[j],thetbeta[j],"  ",tse2[j],"\n")
cat ("\n")
cat ("Heteroskedasticity F Test  ",fh,(1-pchisq(fh,p)),"\n")
cat ("-----------------------------------------", "\n")
cat ("\n")
cat ("\n")
}

# -------------------------functions------------------------- #

qfunc <- function(x){
      out <- x[,(dmin+1):(dmax+1)]
      out 
}

qsort <- function(q){
  n <- nrow(q)
  k <- ncol(q)
  n1 <- round(trim*n)
  if (qnum==0){
    qq <- matrix(0,(n-n1-n1+1),k)/0
    for (j in 1:k){
        qj <- unique(q[,j])
        qj <- as.matrix(sort(qj))
        qj <- as.matrix(qj[n1:(nrow(qj)-n1+1),])
        qq[1:nrow(qj),j] <- qj
    }
  }else{
    qq <- matrix(0,qnum,k)/0
    for (j in 1:k){
        qj <- unique(q[,j])
        qj <- as.matrix(sort(qj))
        qj <- as.matrix(qj[n1:(nrow(qj)-n1+1),])
        nj <- nrow(qj)
        if (nj <= qnum){
            qq[1:nj,j] <- qj
        }else{
            qq[,j] <- qj[ceiling(seq(1,qnum,1)/qnum*nj)]
        }
    }
  }
  qq
}

ginv <- function(m){
     if (qr(m)$rank==ncol(m)) out <- solve(m)
     if (qr(m)$rank<ncol(m)) out <- qr(m)$qr     
     out 
}
# -------------------------functions------------------------- #

# TAR Estimation #
q <- qfunc(x)
qq <- qsort(q)
qn <- ncol(q)
gn <- nrow(qq)
s <- matrix(0,gn,qn)
mmistore <- matrix(0,(k*(k+1)/2),qn*gn)
for (m in 1:qn){
    qm <- as.matrix(q[,m]) 
    for (j in 1:gn){  
        gg <- qq[j,m]
        if (is.nan(gg)==0){  
            xd <- x*((qm <=gg)%*%matrix(1,1,ncol(x))) 
            xxd <- t(xd)%*%xd
            xde <- t(xd)%*%e
            mmi <- ginv(xxd-xxd%*%mi%*%xxd) 
            ii <- 1
            for (i in 1:ncol(mmi)){ 
                mmistore[ii:(ii+i-1),((m-1)*gn+j)] <- mmi[i,1:i]
                ii <- ii+i
            }     
            s[j,m] <- t(xde)%*%mmi%*%xde
        }
    }
}
ghat <- as.matrix(diag(qq[max.col(t(s)),]))
f <- apply(s,2,max)
f <- as.matrix(t*(f/(ee-f)))
mf <- max(f)
di <- which.max(f)
delay <- dmin-1+di
gghat <- ghat[di]

d1 <- as.matrix((q[,di]<=gghat))
d2 <- 1-d1
x1 <- x*(d1%*%matrix(1,1,k))
x2 <- x*(d2%*%matrix(1,1,k))
xx <- cbind(x1,x2)
mxx <- solve(t(xx)%*%xx)
betatar <- mxx%*%(t(xx)%*%y)
etar <- y-xx%*%betatar
xxe <- xx*(etar%*%matrix(1,1,ncol(xx)))
eetar <- t(etar)%*%etar
sigtar <- eetar/t
n1 <- sum(d1)
n2 <- sum(d2)
xxe <- t(xxe)%*%xxe
setar <- sqrt(diag(mxx%*%xxe%*%mxx))
sig1 <- sum((etar*d1)^2)/n1
sig2 <- sum((etar*d2)^2)/n2

e2 <- etar^2
d12 <- cbind(d1,d2)
z <- cbind(d12,(x[,2:k]^2))
mz <- solve(t(z)%*%z)
betaz <- mz%*%(t(z)%*%e2)
u <- e2-z%*%betaz
zu <- z*(u%*%matrix(1,1,ncol(z)))
zu <- t(zu)%*%zu
se3 <- sqrt(diag(mz%*%zu%*%mz))
em <- e2-mean(e2)
fz <- t*((t(em)%*%em)/(t(u)%*%u)-1)
xname3 <- rbind("D1","D2",as.matrix(xname2[2:k]))

# Report TAR estimates #

for (i in 1:1){
cat ("Threshold Autoregression", "\n")
cat ("Sum of Squared Errors             ", eetar, "\n")
cat ("Residual Variance                 ", sigtar, "\n")
cat ("Delay Order                       ", delay, "\n")
cat ("Threshold Estimate                ", gghat, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 1 (Threshold Variable less than or equal to Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
tbetatar <- format(betatar,digits=4)
tsetar <- format(setar,digits=4)
for (j in 1:k) cat (xname[j],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n1, "\n")
cat ("Percentage                        ", (n1/t), "\n")
cat ("Regime Variance                   ", sig1, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 2 (Threshold Variable greater than Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
for (j in (k+1):(2*k)) cat (xname[j-k],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n2, "\n")
cat ("Percentage                        ", (n2/t), "\n")
cat ("Regime Variance                   ", sig2, "\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("Conditional Variance", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
xname3 <- format(xname3,digits=4)
tbetaz <- format(betaz,digits=4)
tse3 <- format(se3,digits=4)
for (j in 1:nrow(betaz)) cat (xname3[j],"  ",tbetaz[j],"  ",tse3[j],"\n")
cat ("\n")
cat ("Heteroskedasticity F Test  ", fz,(1-pchisq(fz,k)), "\n")
cat ("\n")
cat ("-----------------------------------------", "\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("\n")
}

# P-Value Calculations #

# Asymptotic Bootstrap #
ab1 <- matrix(0,boot,p) 
ab2 <- matrix(0,boot,p)
for (i in 1:boot){
  y1 <- as.matrix(rnorm(t,0,1)) 
  e1 <- (y1-x%*%mi%*%(t(x)%*%y1))
  s1 <- matrix(0,gn,qn)
  y2 <- e*y1
  e2 <- (y2-x%*%mi%*%(t(x)%*%y2))
  s2 <- matrix(0,gn,qn)
  for (m in 1:qn){
      qm <- as.matrix(q[,m])
      for (j in 1:gn){ 
          gg <- qq[j,m] 
          if (is.nan(gg)==0){  
              xd <- x*((qm <=gg)%*%matrix(1,1,k))                 
              mmi[upper.tri(mmi,diag=TRUE)] <- mmistore[,(m-1)*gn+j]
              mmiU <- mmi
              mmiU[lower.tri(mmi,diag=FALSE)] <- 0
              mmiL <- t(mmi)
              mmiL[upper.tri(mmi,diag=TRUE)] <- 0
              mmi <- mmiU+mmiL
              xde <- t(xd)%*%e1
              s1[j,m] <- t(xde)%*%mmi%*%xde
              xde <- t(xd)%*%e2
              s2[j,m] <- t(xde)%*%mmi%*%xde
          }
      }
  }
  s1 <- apply(s1,2,max)
  ab1[i,] <- s1
  s2 <- apply(s2,2,max)   
  ab2[i,] <- s2/sig
}
ma1 <- as.matrix(apply(t(ab1),2,max))
apv1 <- as.matrix(colMeans(ab1>(matrix(1,boot,1)%*%t(f))))
ampv1 <- mean(ma1>mf)
ma2 <- as.matrix(apply(t(ab2),2,max))   
apv2 <- as.matrix(colMeans(ab2>(matrix(1,boot,1)%*%t(f))))
ampv2 <- mean(ma2>mf)


# -------------------------functions------------------------- #

dinv <- function(y,x){
     if (qr(x)$rank==ncol(x)) d <- solve(x)%*%y
     if (qr(x)$rank<ncol(x)) d <- ginv(t(x)%*%x)%*%(t(x)%*%y)
     as.matrix(d)
}

tar <- function(dat){
  y <- as.matrix(dat[(p+1):n,])
  x <- cbind(matrix(1,t,1),dat[p:(n-1),])
  for (j in 2:p) x <- cbind(x,dat[(p+1-j):(n-j),]) 
  q <- qfunc(x)
  qq <- qsort(q)
  mi <- ginv(t(x)%*%x)
  e <- y-x%*%mi%*%(t(x)%*%y)
  qn <- ncol(q)
  gn <- nrow(qq)
  s <- matrix(0,gn,qn)
  for (m in 1:qn){
      qm <- as.matrix(q[,m]) 
      for (j in 1:gn){  
          gg <- qq[j,m]
          if (is.nan(gg)==0){ 
              xd <- x*((qm <=gg)%*%matrix(1,1,ncol(x))) 
              xxd <- t(xd)%*%xd
              mmi <- xxd-xxd%*%mi%*%xxd
              xde <- t(xd)%*%e
              s[j,m] <- t(xde)%*%dinv(xde,mmi) 
          }
      }
  }
  f <- apply(s,2,max)
  f <- as.matrix(t*(f/((t(e)%*%e)-f)))
  f
}

ar_sim <- function(y0,beta,e){
  t <- nrow(e)
  u <- as.matrix(e[ceiling(runif(t)*t)]+beta[1])
  yb <- y0
  eols_c <- rbind(y0,u)
  aa <- as.matrix(beta[2:k])
  for (i in (length(y0[,1])+1):(length(eols_c[,1]))){
      datbb <- eols_c[i,]
      for (j in 1:length(y0[,1])){
          datbb <- datbb+aa[j]*yb[(i-j),]
      }
      yb <- rbind(yb,datbb)
  }
  as.matrix(as.vector(yb)) 
}

het_sim <- function(y0,beta,het,e){
  t <- nrow(e)
  u <- as.matrix(e[ceiling(runif(t)*t)])
  y <- rbind(y0,matrix(0,t,1))
  for (j in 1:t){
    x <- rbind(1,as.matrix(rev(y[j:(p+j-1)])))
    h <- t(x^2)%*%het
    y[p+j] <- t(beta)%*%x+sqrt(h*(h>0))*u[j]
  }
  y
}
# -------------------------functions------------------------- #


# Model-Based Bootstrap #
y0 <- as.matrix(dat[1:p,])
# Homoskedastic Error Bootstrap #
  fb <- matrix(0,boot,p)
  for (i in 1:boot) fb[i,] <- t(tar(ar_sim(y0,beta,e)))
  mbt1 <- as.matrix(apply(t(fb),2,max))
  btpv1 <- as.matrix(colMeans(fb>matrix(1,boot,1)%*%t(f)))
  btmpv1 <- mean(mbt1>mf)
# Heteroskedastic Error Bootstrap #
  fb <-  matrix(0,boot,p)
  for (i in 1:boot) fb[i,] <- t(tar(het_sim(y0,beta,hetbeta,eh)))
  mbt2 <- as.matrix(apply(t(fb),2,max))
  btpv2 <- as.matrix(colMeans(fb>matrix(1,boot,1)%*%t(f)))
  btmpv2 <- mean(mbt2>mf)

# Output #
for (i in 1:1){
cat ("Bootstrap Replications      :   ", boot,"\n")
cat ("\n")
names <- cbind(" Delay ","Fstat  ","PV-A-H ","PV-B-H ","PV-A-Het ","PV-B-Het ")
stat <- cbind(as.matrix(seq(1,p,1)),f,apv1,btpv1,apv2,btpv2)
stat <- format (stat, digits=6)
statm <- cbind(mf,ampv1,btmpv1,ampv2,btmpv2)
statm <- format(statm,digits=6)
statm <- cbind("   Max ",statm)
cat (names, "\n")
cat ("------------------------------------------------", "\n")
for (j in 1:p) cat (stat[j,1],stat[j,2],stat[j,3],stat[j,4],stat[j,5],stat[j,6],"\n")
cat (statm, "\n")
cat ("\n")
cat ("\n")
}

# -------------------------functions------------------------- #

kernel <- function(x,b){
  h <- 1.7*sd(x)/(nrow(x)^(.2))
  g <- nrow(b)
  kern <- matrix(0,g,1)
  for (i in 1:g){
      u <- abs(b[i]-x)/h
      kern[i] <- mean((1-u^2)*(u<=1))*(.75)/h
  }
  kern
}

quant <- function(x,q){
  s <- as.matrix(sort(x))
  qq <- s[round(nrow(s)*q)]
  qq
}
# -------------------------functions------------------------- #

# Density Calculation #
qm <- .99
ub <- max(rbind(quant(ma1,qm),quant(ma2,qm),quant(mbt1,qm),quant(mbt2,qm)))
k_x <- as.matrix(seq(0,ub,ub/999))
k1 <- (k_x^((k/2)-1))*exp(-k_x/2)/(gamma(k/2)*(2^(k/2)))
k1 <- cbind(k1,kernel(ma1,k_x),kernel(mbt1,k_x),kernel(ma2,k_x),kernel(mbt2,k_x))
sun_k1 <- cbind(k_x,k1)
save(sun_k1, file = "sun_k1.RData")



