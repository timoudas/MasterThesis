##  SUNSPOT3.R
##
##  This replicates some of the empirical work reported in 
##  "Testing for Linearity" by Bruce E. Hansen.
##  For updates and contact information, see my webpage
##  www.ssc.wisc.edu/~bhansen
## 
## 
##  This program estimates a two-threshold TAR model, and tests the null of a 
##  one-threshold TAR against the alternative of a two-threshold TAR 
##
###########################################################################

dat <- read.table("sunspot.dat")
dat <- (sqrt(1+dat)-1)*2   # load and define univariate series 
yname <- "Sunspots"	   # name of series 
p <- 11		# order of autoregression 
dmin <- 1		# minimal delay order 
dmax <- p		# maximal delay order (set to p or less 
trim <- .1		# minimal percentage of data per regime 
qnum <- 100	      # Number of thresholds to search. 
                  # Set _qnum=0 to search over all values 
boot <- 1000	# bootstrap replications 

#-------------------------------------------------------------------------#


# Define Data #
n <- nrow(dat)
y <- as.matrix(dat[(p+1):n,])
t <- n-p
x <- cbind(matrix(1,t,1),dat[p:(n-1),])
xname <- rbind("Constant","Y(t-01) ")
xname2 <- rbind("Constant","Y(t-01)^2 ")
for (j in 2:p){
    x <- cbind(x,dat[(p+1-j):(n-j),]) 
    if (j<10){ pn <- paste(c("0"),j,sep="")
    }else{ pn <- as.character(j)}
    namej <- paste(c("Y(t-"),pn,c(")"),sep="")
    xname <- rbind(xname,namej)
    xname2 <- rbind(xname2,paste(namej,c("^2"),sep=""))
}
k <- ncol(x)

# -------------------------functions------------------------- #

qsort <- function(q){
  n <- nrow(q)
  k <- ncol(q)
  n1 <- round(trim*n)
  if (qnum==0){
    qq <- matrix(0,(n-n1-n1+1),k)/0
    for (j in 1:k){
        qj <- unique(q[,j])
        qj <- as.matrix(sort(qj))
        qj <- as.matrix(qj[n1:(nrow(qj)-n1+1),])
        qq[1:nrow(qj),j] <- qj
    }
  }else{
    qq <- matrix(0,qnum,k)/0
    for (j in 1:k){
        qj <- unique(q[,j])
        qj <- as.matrix(sort(qj))
        qj <- as.matrix(qj[n1:(nrow(qj)-n1+1),])
        nj <- nrow(qj)
        if (nj <= qnum){
            qq[1:nj,j] <- qj
        }else{
            qq[,j] <- qj[ceiling(seq(1,qnum,1)/qnum*nj)]
        }
    }
  }
  qq
}

qsort_2 <- function(q,ghat){
  n <- nrow(q)
  n1 <- round(trim*n)
  qq <- unique(q)
  qq <- as.matrix(sort(qq))
  qq <- as.matrix(qq[n1:(nrow(qq)-n1+1),])
  ii <- abs(seq(1,nrow(qq),1)-which.max(qq>=ghat))<n1  
  qq <- as.matrix(qq[ii!=1])
  if (qnum>0){
    nq <- nrow(qq)
    if (nq>qnum) qq <- qq[ceiling(seq(1,qnum,1)/qnum*nq)]
  }     
  as.matrix(qq)
}

qfunc <- function(x){
      out <- x[,(dmin+1):(dmax+1)]
      out 
}

ginv <- function(m){
     if (qr(m)$rank==ncol(m)) out <- solve(m)
     if (qr(m)$rank<ncol(m)) out <- qr(m)$qr     
     out 
}

dinv <- function(y,x){
     if (qr(x)$rank==ncol(x)) d <- solve(x)%*%y
     if (qr(x)$rank<ncol(x)) d <- ginv(t(x)%*%x)%*%(t(x)%*%y)
     as.matrix(d)
}

tar <- function(y,x,q,qq){
  mi <- ginv(t(x)%*%x)
  e <- y-x%*%mi%*%(t(x)%*%y)
  qn <- ncol(q)
  gn <- nrow(qq)
  s <- matrix(0,gn,qn)
  for (m in 1:qn){
      qm <- as.matrix(q[,m]) 
      for (j in 1:gn){  
          gg <- qq[j,m]
          if (is.nan(gg)==0){ 
              xd <- x*((qm <=gg)%*%matrix(1,1,ncol(x))) 
              xxd <- t(xd)%*%xd
              mmi <- xxd-xxd%*%mi%*%xxd
              xde <- t(xd)%*%e
              s[j,m] <- t(xde)%*%dinv(xde,mmi) 
          }
      }
  }  
  dhat <- which.max(apply(s,2,max))
  ghat <- qq[which.max(s[,dhat]),dhat]
  list(dhat=dhat,ghat=ghat)
}

tar_d <- function(y,x,x1,q,qq){
  mi <- ginv(t(x)%*%x)
  e <- y-x%*%mi%*%(t(x)%*%y)
  gn <- nrow(qq)
  s <- matrix(0,gn,1)
  for (j in 1:gn){  
      gg <- qq[j]
      if (is.nan(gg)==0){ 
          xd <- cbind(x1,(x*((q <=gg)%*%matrix(1,1,ncol(x))))) 
          xxd <- t(xd)%*%xd
          xdx <- t(x)%*%xd
          mmi <- xxd-t(xdx)%*%mi%*%xdx
          xde <- t(xd)%*%e
          s[j] <- t(xde)%*%dinv(xde,mmi) 
      }
  }
  f <- as.matrix(apply(s,2,max))
  ghat <- qq[which.max(s)]  
  ghat
}

tar2 <- function(dat){
  y <- as.matrix(dat[(p+1):n,])
  x <- cbind(matrix(1,t,1),dat[p:(n-1),])
  for (j in 2:p) x <- cbind(x,dat[(p+1-j):(n-j),])
  q <- qfunc(x)
  out <- tar(y,x,q,qsort(q))   # fit TAR-1 model #
  dhat <- out$dhat 
  ghat <- out$ghat
  qd <- as.matrix(q[,dhat])
  x1 <- x*((qd<=ghat)%*%matrix(1,1,ncol(x)))
  xx <- cbind(x1,x)
  e <- y-xx%*%(qr.solve(xx,y))
  ghat2 <- tar_d(y,x,x1,qd,qsort_2(qd,ghat))   # fit TAR-2 model #
  x1 <- x*((qd<=ghat2)%*%matrix(1,1,ncol(x))) 
  ghat1 <- tar_d(y,x,x1,qd,qsort_2(qd,ghat2))  # iterated estimate of gamma_1 #
  x1 <- x*((qd<=ghat1)%*%matrix(1,1,ncol(x))) 
  ghat2 <- tar_d(y,x,x1,qd,qsort_2(qd,ghat1))  # iterated estimate of gamma_2 #
  if (ghat2<ghat1){
      gg <- ghat1
      ghat1 <- ghat2
      ghat2 <- gg
  }
  d1 <- (qd<=ghat1)
  d2 <- (qd<=ghat2)*(1-d1)
  xx <- cbind((x*(d1%*%matrix(1,1,k))),(x*(d2%*%matrix(1,1,k))),(x*((1-d1-d2)%*%matrix(1,1,k))))
  etar <- y-xx%*%(qr.solve(xx,y))
  f <- t*(((t(e)%*%e)/(t(etar)%*%etar))-1)
  list(f=f,dhat=dhat,ghat=ghat,ghat1=ghat1,ghat2=ghat2)
}
# -------------------------functions------------------------- #

# TAR Estimation #

out <- tar2(dat)
f <- out$f
dhat <- out$dhat
ghat <- out$ghat
ghat1 <- out$ghat1
ghat2 <- out$ghat2

q <- qfunc(x)
qd <- as.matrix(q[,dhat])
delay <- dmin-1+dhat


# TAR_1 Model #

d1 <- (qd<=ghat)
d2 <- 1-d1
xx <- cbind((x*(d1%*%matrix(1,1,k))),(x*(d2%*%matrix(1,1,k))))
mxx <- solve(t(xx)%*%xx)
beta <- mxx%*%(t(xx)%*%y)
e <- y-xx%*%beta
xxe <- xx*(e%*%matrix(1,1,ncol(xx)))
ee <- t(e)%*%e
sig <- ee/t
n1 <- sum(d1)
n2 <- sum(d2)
se <- sqrt(diag(mxx%*%(t(xxe)%*%xxe)%*%mxx))
b1 <- as.matrix(beta[1:k])
b2 <- as.matrix(beta[(k+1):(2*k)])
e1 <- as.matrix(e[d1])
e2 <- as.matrix(e[d2])
sig1 <- (t(e1)%*%e1)/n1
sig2 <- (t(e2)%*%e2)/n2

yz <- e^2
d12 <- cbind(d1,d2)
z <- cbind(d12,(x[,2:k]^2))
mz <- solve(t(z)%*%z)
betaz <- mz%*%(t(z)%*%yz)
h <- z%*%betaz
u <- yz-h
zu <- z*(u%*%matrix(1,1,ncol(z)))
zzu <- t(zu)%*%zu
se3 <- sqrt(diag(mz%*%zzu%*%mz))
em <- yz-mean(yz)
fz <- t*((t(em)%*%em)/(t(u)%*%u)-1)
xname3 <- rbind("D1","D2",as.matrix(xname2[2:k]))
ez <- e/sqrt(h*(h>0)+(h<=0))*(h>0)

for (i in 1:1){
cat ("Dependent Variable:     ", yname, "\n")
cat ("\n")
cat ("Threshold Autoregression, Single Threshold", "\n")
cat ("Sum of Squared Errors             ", ee, "\n")
cat ("Residual Variance                 ", sig, "\n")
cat ("Delay Order                       ", delay, "\n")
cat ("Threshold Estimate                ", ghat, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 1 (Threshold Variable less than or equal to Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
tb1 <- format(b1,digits=4)
tb2 <- format(b2,digits=4)
tse <- format(se,digits=4)
for (j in 1:k) cat (xname[j],"  ",tb1[j],"  ",tse[j],"\n")
cat ("\n")
cat ("Observations                      ", n1, "\n")
cat ("Percentage                        ", (n1/t), "\n")
cat ("Regime Variance                   ", sig1, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 2 (Threshold Variable greater than Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
for (j in (k+1):(2*k)) cat (xname[j-k],"  ",tb2[j-k],"  ",tse[j],"\n")
cat ("\n")
cat ("Observations                      ", n2, "\n")
cat ("Percentage                        ", (n2/t), "\n")
cat ("Regime Variance                   ", sig2, "\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("Conditional Variance", "\n")
cat ("\n")
cat ("Variable     ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
xname3 <- format(xname3,digits=4)
tbetaz <- format(betaz,digits=4)
tse3 <- format(se3,digits=4)
for (j in 1:nrow(betaz)) cat (xname3[j],"  ",tbetaz[j],"  ",tse3[j],"\n")
cat ("\n")
cat ("Heteroskedasticity F Test  ", fz,(1-pchisq(fz,k)), "\n")
cat ("\n")
cat ("-----------------------------------------", "\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("\n")
}

# TAR_2 Model #

d1 <- (qd<=ghat1)
d2 <- (qd<=ghat2)*(1-d1)
d3 <- 1-d1-d2
xx <- cbind((x*(d1%*%matrix(1,1,k))),(x*(d2%*%matrix(1,1,k))),(x*(d3%*%matrix(1,1,k))))
mxx <- solve(t(xx)%*%xx)
betatar <- mxx%*%(t(xx)%*%y)
etar <- y-xx%*%betatar
xxe <- xx*(etar%*%matrix(1,1,ncol(xx)))
eetar <- t(etar)%*%etar
sigtar <- eetar/t
n1 <- sum(d1)
n2 <- sum(d2)
n3 <- sum(d3)
setar <- sqrt(diag(mxx%*%(t(xxe)%*%xxe)%*%mxx))
sig1 <- sum((etar*d1)^2)/n1
sig2 <- sum((etar*d2)^2)/n2
sig3 <- sum((etar*d3)^2)/n3

for (i in 1:1){
cat ("Threshold Autoregression, Double Threshold", "\n")
cat ("Sum of Squared Errors             ", eetar, "\n")
cat ("Residual Variance                 ", sigtar, "\n")
cat ("Delay Order                       ", delay, "\n")
cat ("First Threshold Estimate          ", ghat1, "\n")
cat ("Second Threshold Estimate         ", ghat2, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 1 (Threshold Variable less than or equal to First Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
tbetatar <- format(betatar,digits=4)
tsetar <- format(setar,digits=4)
for (j in 1:k) cat (xname[j],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n1, "\n")
cat ("Percentage                        ", (n1/t), "\n")
cat ("Regime Variance                   ", sig1, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 2 (Threshold Variable Between Thresholds):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
for (j in (k+1):(2*k)) cat (xname[j-k],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n2, "\n")
cat ("Percentage                        ", (n2/t), "\n")
cat ("Regime Variance                   ", sig2, "\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("Regime 3 (Threshold Variable Above Second Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
for (j in (2*k+1):(3*k)) cat (xname[j-2*k],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n3, "\n")
cat ("Percentage                        ", (n3/t), "\n")
cat ("Regime Variance                   ", sig3, "\n")
cat ("\n")
cat ("\n")
cat ("\n")
}

# -------------------------functions------------------------- #

tar_sim1 <- function(y0,b1,b2,delay,g,e){
  u <- as.matrix(e[ceiling(runif(t)*t)])
  y <- rbind(y0,matrix(0,t,1))
  for (j in 1:t){
    x <- as.matrix(rev(y[j:(p+j-1)]))
    q <- x[delay]
    x <- rbind(1,x)
    y[p+j] <- (t(b1)%*%x)*(q<=g)+(t(b2)%*%x)*(q>g)+u[j]
  }
  y
}

tar_sim2 <- function(y0,b1,b2,delay,g,e1,e2){
  y <- rbind(y0,matrix(0,t,1))
  u <- as.matrix(runif(t))
  u1 <- as.matrix(e1[ceiling(u*nrow(e1))])
  u2 <- as.matrix(e2[ceiling(u*nrow(e2))])
  for (j in 1:t){
    x <- as.matrix(rev(y[j:(p+j-1)]))
    xx <- rbind(1,x)
    q <- x[delay]
    y[p+j] <- (t(b1)%*%xx+u1[j])*(q<=g)+(t(b2)%*%xx+u2[j])*(q>g)
  }
  y
}
# -------------------------functions------------------------- #

# Model-Based Bootstrap, Homoskedastic Errors #
  y0 <- as.matrix(dat[1:p,])
  fb1 <- matrix(0,boot,1)
  for (i in 1:boot){ 
      out <- tar2(tar_sim1(y0,b1,b2,delay,ghat,e))
      fb1[i] <- out$f
  }
  pv1 <- mean(fb1>as.vector(f))

# Model-Based Bootstrap, Regime-Specific Errors #
  fb2 <- matrix(0,boot,1)
  for (i in 1:boot){ 
      out <- tar2(tar_sim2(y0,b1,b2,delay,ghat,e1,e2))
      fb2[i] <- out$f
  }
  pv2 <- mean(fb2>as.vector(f))

# Model-Based Bootstrap, Heteroskedastic Errors #
  fb3 <- matrix(0,boot,1)
  for (i in 1:boot){ 
      out <- tar2(tar_sim2(y0,b1,b2,delay,ghat,betaz,ez))
      fb3[i] <- out$f
  }
  pv3 <- mean(fb3>as.vector(f))

# Output #
for (i in 1:1){
names <- cbind("Fstat  ","PV-1  ","PV-2  ", "PV-3")
statm <- cbind(f,pv1,pv2,pv3)
statm <- format(statm,digits=6)
cat ("Bootstrap Replications      :   ", boot,"\n")
cat ("\n")
cat ("TAR Tests, P-Values", "\n")
cat ("\n")
cat (names, "\n")
cat ("------------------------------------------------", "\n")
cat (statm, "\n")
cat ("\n")
cat ("\n")
}

# -------------------------functions------------------------- #

kernel <- function(x,b){
  h <- 1.7*sd(x)/(nrow(x)^(.2))
  g <- nrow(b)
  kern <- matrix(0,g,1)
  for (i in 1:g){
      u <- abs(b[i]-x)/h
      kern[i] <- mean((1-u^2)*(u<=1))*(.75)/h
  }
  kern
}

quant <- function(x,q){
  s <- as.matrix(sort(x))
  qq <- s[round(nrow(s)*q)]
  qq
}
# -------------------------functions------------------------- #

# Density Calculation #

ub <- max(rbind(quant(fb1,.99),quant(fb2,.99),quant(fb3,.99)))
k_x <- as.matrix(seq(0,ub,ub/999))
k_chi <- (k_x^((k/2)-1))*exp(-k_x/2)/(gamma(k/2)*(2^(k/2)))
kern <- cbind(k_chi,kernel(fb1,k_x),kernel(fb2,k_x),kernel(fb3,k_x))
sun_k3 <- cbind(k_x,kern)
save(sun_k3, file = "sun_k3.RData")



