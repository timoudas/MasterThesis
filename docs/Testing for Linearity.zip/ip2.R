##  IP2.R 
##
##  This replicates some of the empirical work reported in 
##  "Testing for Linearity" by Bruce E. Hansen.
##  For updates and contact information, see my webpage
##  www.ssc.wisc.edu/~bhansen
## 
## 
##  This program estimates a two-threshold TAR model, and tests the null of a 
##  one-regime AR against the alternative of a three-regime TAR 
##
###########################################################################

yname <- "Industrial Production"	# name of series 
dat <- read.table("ip.dat")         # load and define univariate series 
dat <- as.matrix(log(dat))
dat <- as.matrix((dat[13:nrow(dat)]-dat[1:(nrow(dat)-12)])*100)
dat <- as.matrix(dat[157:nrow(dat)])
 
p <- 16		# order of autoregression 
dmin <- 1		# minimal delay order 
dmax <- p		# maximal delay order (set to p or less 
trim <- .1		# minimal percentage of data per regime 
qnum <- 100	      # Number of thresholds to search. 
                  # Set _qnum=0 to search over all values 
boot <- 1000	# bootstrap replications 

#-------------------------------------------------------------------------#

# Define Data #
n <- nrow(dat)
y <- as.matrix(dat[(p+1):n,])
t <- n-p
x <- cbind(matrix(1,t,1),dat[p:(n-1),])
xname <- rbind("Constant","Y(t-01) ")
xname2 <- rbind("Constant","Y(t-01)^2 ")
for (j in 2:p){
    x <- cbind(x,dat[(p+1-j):(n-j),]) 
    if (j<10){ pn <- paste(c("0"),j,sep="")
    }else{ pn <- as.character(j)}
    namej <- paste(c("Y(t-"),pn,c(")"),sep="")
    xname <- rbind(xname,namej)
    xname2 <- rbind(xname2,paste(namej,c("^2"),sep=""))
}
k <- ncol(x)

# Linear Regression #
mi <- solve(t(x)%*%x)
beta <- mi%*%(t(x)%*%y)
e <- y-x%*%beta
ee <- t(e)%*%e
xe <- x*(e%*%matrix(1,1,ncol(x)))
sig <- ee/t
xee <- t(xe)%*%xe
se <- as.matrix(sqrt(diag(mi%*%xee%*%mi)))

# Conditional Variance #
e2 <- e^2
x2 <- x^2
m2 <- solve(t(x2)%*%x2)
hetbeta <- m2%*%(t(x2)%*%e2)
h <- x2%*%hetbeta
eh <- e/sqrt(h*(h>0)+(h<=0))*(h>0)
u <- e2-h
x2u <- x2*(u%*%matrix(1,1,ncol(x2)))
x2u <- t(x2u)%*%x2u
se2 <- as.matrix(sqrt(diag(m2%*%x2u%*%m2)))
em <- e2-mean(e2)
fh <- t*((t(em)%*%em)/(t(u)%*%u)-1)

# Report Linear Estimation #
for (i in 1:1){
cat ("Dependent Variable:     ", yname, "\n")
cat ("\n")
cat ("Linear Autoregression", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
xname <- format(xname,digits=4)
tbeta <- format(beta,digits=4)
tse <- format(se,digits=4)
for (j in 1:nrow(beta)) cat (xname[j],"  ",tbeta[j],"  ",tse[j],"\n")
cat ("\n")
cat ("Observations                      ", t, "\n")
cat ("Sum of Squared Errors             ", ee, "\n")
cat ("Residual Variance                 ", sig, "\n")
cat ("\n")
cat ("\n")
cat ("Conditional Variance", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
xname2 <- format(xname2,digits=4)
thetbeta <- format(hetbeta,digits=4)
tse2 <- format(se2,digits=4)
for (j in 1:nrow(beta)) cat (xname2[j],thetbeta[j],"  ",tse2[j],"\n")
cat ("\n")
cat ("Heteroskedasticity F Test  ",fh,(1-pchisq(fh,p)),"\n")
cat ("-----------------------------------------", "\n")
cat ("\n")
cat ("\n")
}


# -------------------------functions------------------------- #

qsort <- function(q){
  n <- nrow(q)
  k <- ncol(q)
  n1 <- round(trim*n)
  if (qnum==0){
    qq <- matrix(0,(n-n1-n1+1),k)/0
    for (j in 1:k){
        qj <- unique(q[,j])
        qj <- as.matrix(sort(qj))
        qj <- as.matrix(qj[n1:(nrow(qj)-n1+1),])
        qq[1:nrow(qj),j] <- qj
    }
  }else{
    qq <- matrix(0,qnum,k)/0
    for (j in 1:k){
        qj <- unique(q[,j])
        qj <- as.matrix(sort(qj))
        qj <- as.matrix(qj[n1:(nrow(qj)-n1+1),])
        nj <- nrow(qj)
        if (nj <= qnum){
            qq[1:nj,j] <- qj
        }else{
            qq[,j] <- qj[ceiling(seq(1,qnum,1)/qnum*nj)]
        }
    }
  }
  qq
}

qsort_2 <- function(q,ghat){
  n <- nrow(q)
  n1 <- round(trim*n)
  qq <- unique(q)
  qq <- as.matrix(sort(qq))
  qq <- as.matrix(qq[n1:(nrow(qq)-n1+1),])
  ii <- abs(seq(1,nrow(qq),1)-which.max(qq>=ghat))<n1  
  qq <- as.matrix(qq[ii!=1])
  if (qnum>0){
    nq <- nrow(qq)
    if (nq>qnum) qq <- qq[ceiling(seq(1,qnum,1)/qnum*nq)]
  }     
  as.matrix(qq)
}

qfunc <- function(x){
      out <- x[,(dmin+1):(dmax+1)]
      out 
}

ginv <- function(m){
     if (qr(m)$rank==ncol(m)) out <- solve(m)
     if (qr(m)$rank<ncol(m)) out <- qr(m)$qr     
     out 
}

dinv <- function(y,x){
     if (qr(x)$rank==ncol(x)) d <- solve(x)%*%y
     if (qr(x)$rank<ncol(x)) d <- ginv(t(x)%*%x)%*%(t(x)%*%y)
     as.matrix(d)
}

tar <- function(y,x,q,qq){
  mi <- ginv(t(x)%*%x)
  e <- y-x%*%mi%*%(t(x)%*%y)
  qn <- ncol(q)
  gn <- nrow(qq)
  s <- matrix(0,gn,qn)
  for (m in 1:qn){
      qm <- as.matrix(q[,m]) 
      for (j in 1:gn){  
          gg <- qq[j,m]
          if (is.nan(gg)==0){ 
              xd <- x*((qm <=gg)%*%matrix(1,1,ncol(x))) 
              xxd <- t(xd)%*%xd
              mmi <- xxd-xxd%*%mi%*%xxd
              xde <- t(xd)%*%e
              s[j,m] <- t(xde)%*%dinv(xde,mmi) 
          }
      }
  }  
  dhat <- which.max(apply(s,2,max))
  ghat <- qq[which.max(s[,dhat]),dhat]
  list(dhat=dhat,ghat=ghat)
}

tar_d <- function(y,x,x1,q,qq){
  mi <- ginv(t(x)%*%x)
  e <- y-x%*%mi%*%(t(x)%*%y)
  gn <- nrow(qq)
  s <- matrix(0,gn,1)
  for (j in 1:gn){  
      gg <- qq[j]
      if (is.nan(gg)==0){ 
          xd <- cbind(x1,(x*((q <=gg)%*%matrix(1,1,ncol(x))))) 
          xxd <- t(xd)%*%xd
          xdx <- t(x)%*%xd
          mmi <- xxd-t(xdx)%*%mi%*%xdx
          xde <- t(xd)%*%e
          s[j] <- t(xde)%*%dinv(xde,mmi) 
      }
  }
  f <- as.matrix(apply(s,2,max))
  ghat <- qq[which.max(s)]  
  list(f=f,ghat=ghat)
}

tar2 <- function(dat){
  y <- as.matrix(dat[(p+1):n,])
  x <- cbind(matrix(1,t,1),dat[p:(n-1),])
  for (j in 2:p) x <- cbind(x,dat[(p+1-j):(n-j),])
  e <- y-x%*%(qr.solve(x,y)) 
  q <- qfunc(x)
  out <- tar(y,x,q,qsort(q))   # fit TAR-1 model #
  dhat <- out$dhat 
  ghat1 <- out$ghat
  qd <- as.matrix(q[,dhat])
  x1 <- x*((qd<=ghat1)%*%matrix(1,1,ncol(x)))
  out <- tar_d(y,x,x1,qd,qsort_2(qd,ghat1))  # fit TAR-2 model #
  f <- out$f
  ghat2 <- out$ghat 
  x1 <- x*((qd<=ghat2)%*%matrix(1,1,ncol(x))) 
  out <- tar_d(y,x,x1,qd,qsort_2(qd,ghat2))  # iterated estimate of gamma_1 #
  f <- out$f
  ghat1 <- out$ghat 
  x1 <- x*((qd<=ghat1)%*%matrix(1,1,ncol(x))) 
  out <- tar_d(y,x,x1,qd,qsort_2(qd,ghat1))  # iterated estimate of gamma_2 #
  f <- out$f
  ghat2 <- out$ghat 
  f <- t/(((t(e)%*%e)/f)-1)
  if (ghat2<ghat1){
      gg <- ghat1
      ghat1 <- ghat2
      ghat2 <- gg
  }
  list(f=f,dhat=dhat,ghat1=ghat1,ghat2=ghat2)
}
# -------------------------functions------------------------- #

# TAR Estimation #

out <- tar2(dat)
f <- out$f
dhat <- out$dhat
ghat1 <- out$ghat1
ghat2 <- out$ghat2
q <- qfunc(x)
qd <- as.matrix(q[,dhat])
delay <- dmin-1+dhat
d1 <- (qd<=ghat1)
d2 <- (qd<=ghat2)*(1-d1)
d3 <- 1-d1-d2
xx <- cbind((x*(d1%*%matrix(1,1,k))),(x*(d2%*%matrix(1,1,k))),(x*(d3%*%matrix(1,1,k))))
mxx <- solve(t(xx)%*%xx)
betatar <- mxx%*%(t(xx)%*%y)
etar <- y-xx%*%betatar
xxe <- xx*(etar%*%matrix(1,1,ncol(xx)))
eetar <- t(etar)%*%etar
sigtar <- eetar/t
n1 <- sum(d1)
n2 <- sum(d2)
n3 <- sum(d3)
setar <- sqrt(diag(mxx%*%(t(xxe)%*%xxe)%*%mxx))
sig1 <- sum((etar*d1)^2)/n1
sig2 <- sum((etar*d2)^2)/n2
sig3 <- sum((etar*d3)^2)/n3

# Report TAR estimates #

for (i in 1:1){
cat ("Threshold Autoregression", "\n")
cat ("Sum of Squared Errors             ", eetar, "\n")
cat ("Residual Variance                 ", sigtar, "\n")
cat ("Delay Order                       ", delay, "\n")
cat ("First Threshold Estimate          ", ghat1, "\n")
cat ("Second Threshold Estimate         ", ghat2, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 1 (Threshold Variable less than or equal to First Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
tbetatar <- format(betatar,digits=4)
tsetar <- format(setar,digits=4)
for (j in 1:k) cat (xname[j],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n1, "\n")
cat ("Percentage                        ", (n1/t), "\n")
cat ("Regime Variance                   ", sig1, "\n")
cat ("\n")
cat ("\n")
cat ("Regime 2 (Threshold Variable Between Thresholds):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
for (j in (k+1):(2*k)) cat (xname[j-k],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n2, "\n")
cat ("Percentage                        ", (n2/t), "\n")
cat ("Regime Variance                   ", sig2, "\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("\n")
cat ("Regime 3 (Threshold Variable Above Second Threshold):", "\n")
cat ("\n")
cat ("Variable   ","Estimate   ","St Error   ", "\n")
cat ("-----------------------------------------", "\n")
for (j in (2*k+1):(3*k)) cat (xname[j-2*k],"  ",tbetatar[j],"  ",tsetar[j],"\n")
cat ("\n")
cat ("Observations                      ", n3, "\n")
cat ("Percentage                        ", (n3/t), "\n")
cat ("Regime Variance                   ", sig3, "\n")
cat ("\n")
cat ("\n")
cat ("\n")
}



# -------------------------functions------------------------- #

ar_sim <- function(y0,beta,e){
  t <- nrow(e)
  u <- as.matrix(e[ceiling(runif(t)*t)]+beta[1])
  yb <- y0
  eols_c <- rbind(y0,u)
  aa <- as.matrix(beta[2:k])
  for (i in (length(y0[,1])+1):(length(eols_c[,1]))){
      datbb <- eols_c[i,]
      for (j in 1:length(y0[,1])){
          datbb <- datbb+aa[j]*yb[(i-j),]
      }
      yb <- rbind(yb,datbb)
  }
  as.matrix(as.vector(yb)) 
}

het_sim <- function(y0,beta,het,e){
  t <- nrow(e)
  u <- as.matrix(e[ceiling(runif(t)*t)])
  y <- rbind(y0,matrix(0,t,1))
  for (j in 1:t){
    x <- rbind(1,as.matrix(rev(y[j:(p+j-1)])))
    h <- t(x^2)%*%het
    y[p+j] <- t(beta)%*%x+sqrt(h*(h>0))*u[j]
  }
  y
}
# -------------------------functions------------------------- #

# Model-Based Bootstrap, Homoskedastic Errors #
  y0 <- as.matrix(dat[1:p,])
  fb <- matrix(0,boot,1)
  for (i in 1:boot){ 
      out <- tar2(ar_sim(y0,beta,e))
      fb[i] <- out$f
  }
  btpv <- mean(fb>as.vector(f))

# Model-Based Bootstrap, Heteroskedastic Errors #
  y0 <- as.matrix(dat[1:p,])
  fbh <- matrix(0,boot,1)
  for (i in 1:boot){ 
      out <- tar2(het_sim(y0,beta,hetbeta,eh))
      fbh[i] <- out$f
  }
  btpvh <- mean(fbh>as.vector(f))

# Output #
for (i in 1:1){
names <- cbind("Fstat    ","PV-BT  ","PV-BT-H ")
statm <- cbind(f,btpv,btpvh)
statm <- format(statm,digits=6)
cat ("Bootstrap Replications      :   ", boot,"\n")
cat ("\n")
cat ("TAR Tests, P-Values", "\n")
cat ("\n")
cat (names, "\n")
cat ("------------------------------------------------", "\n")
cat (statm, "\n")
cat ("\n")
cat ("\n")
}

# -------------------------functions------------------------- #

kernel <- function(x,b){
  h <- 1.7*sd(x)/(nrow(x)^(.2))
  g <- nrow(b)
  kern <- matrix(0,g,1)
  for (i in 1:g){
      u <- abs(b[i]-x)/h
      kern[i] <- mean((1-u^2)*(u<=1))*(.75)/h
  }
  kern
}

quant <- function(x,q){
  s <- as.matrix(sort(x))
  qq <- s[round(nrow(s)*q)]
  qq
}
# -------------------------functions------------------------- #

# Density Calculation #

ub <- max(rbind(quant(fb,.99),quant(fbh,.99)))
k_x <- as.matrix(seq(0,ub,ub/999))
k_chi <- (k_x^((k)-1))*exp(-k_x/2)/(gamma(k)*(2^(k)))
kern <- cbind(k_chi,kernel(fb,k_x),kernel(fbh,k_x))
ip_k2 <- cbind(k_x,kern)
save(ip_k2, file = "ip_k2.RData")



