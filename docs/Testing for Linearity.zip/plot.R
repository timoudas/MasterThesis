##  PLOT.R 
##
##  This program produces the graphs shown in
##  "Testing for Linearity" by Bruce E. Hansen.
##  For updates and contact information, see my webpage
##  www.ssc.wisc.edu/~bhansen
##
###########################################################################

load("sun_k1.RData")
load("sun_k2.RData")
load("sun_k3.RData")
load("ip_k1.RData")
load("ip_k2.RData")
load("ip_k3.RData")

rt <- 0  # to rotate graphs and create .eps files # ### check  

ss <- read.table("sunspot.dat")
ss <- as.matrix((sqrt(1+ss)-1)*2)
n <- nrow(ss)
xs <- as.matrix(seq(1988-n,1987,1))
x11()
plot(xs,ss,lty=1,col=1,type="l",ann=0)
title(main="Figure 1: Annual Sunspot Means, 1700-1988")


ip <- read.table("ip.dat")         
ip <- as.matrix(log(ip))
ip <- as.matrix((ip[13:nrow(ip)]-ip[1:(nrow(ip)-12)])*100)
ip <- as.matrix(ip[157:nrow(ip)])
xp <- as.matrix(seq(1960,(1960+(nrow(ip)-1)/12),1/12))
x11()
plot(xp,ip,lty=1,col=1,type="l",ann=0)
tit <- rbind("Figure 2: U.S. Monthly Industrial Production","Annual Growth, 1960-1998") 
title(main=tit)


x11()
xxlim <- range(sun_k1[,1])
yylim <- range(sun_k1[,(2:6)])
tit <- rbind("Figure 3: Sunspot Series","Asymptotic and Bootstrap Distributions of F12");
xxlab <- "Bootstrap Distributions of F12"
plot(sun_k1[,1],sun_k1[,2],lty=1,col=1,xlim=xxlim,ylim=yylim,type="l",ann=0)
lines(sun_k1[,1],sun_k1[,3],lty=2,col=2) 
lines(sun_k1[,1],sun_k1[,4],lty=3,col=3)
lines(sun_k1[,1],sun_k1[,5],lty=4,col=4)
lines(sun_k1[,1],sun_k1[,6],lty=5,col=5)
title(main=tit,xlab=xxlab)
t1 <- "Chi-Square(k)"
t2 <- "Asymptotic (Homo.)"
t3 <- "Bootstrap (Homo.)"
t4 <- "Asymptotic (Hetero.)"
t5 <- "Bootstrap (Hetero.)"   
legend("topright",c(t1,t2,t3,t4,t5),lty=c(1,2,3,4,5),col=c(1,2,3,4,5))

x11()
xxlim <- range(ip_k1[,1])
yylim <- range(ip_k1[,(2:6)])
tit <- rbind("Figure 4: Industrial Production","Asymptotic and Bootstrap Distributions of F12");
xxlab <- "Bootstrap Distributions of F12"
plot(ip_k1[,1],ip_k1[,2],lty=1,col=1,xlim=xxlim,ylim=yylim,type="l",ann=0)
lines(ip_k1[,1],ip_k1[,3],lty=2,col=2) 
lines(ip_k1[,1],ip_k1[,4],lty=3,col=3)
lines(ip_k1[,1],ip_k1[,5],lty=4,col=4)
lines(ip_k1[,1],ip_k1[,6],lty=5,col=5)
title(main=tit,xlab=xxlab)
t1 <- "Chi-Square(k)"
t2 <- "Asymptotic (Homo.)"
t3 <- "Bootstrap (Homo.)"
t4 <- "Asymptotic (Hetero.)"
t5 <- "Bootstrap (Hetero.)"   
legend("topright",c(t1,t2,t3,t4,t5),lty=c(1,2,3,4,5),col=c(1,2,3,4,5))

x11()
xxlim <- range(sun_k2[,1])
yylim <- range(sun_k2[,(2:4)])
tit <- rbind("Figure 5: Sunspot Series","Asymptotic and Bootstrap Distributions of F13");
plot(sun_k2[,1],sun_k2[,2],lty=1,col=1,xlim=xxlim,ylim=yylim,type="l",ann=0)
lines(sun_k2[,1],sun_k2[,3],lty=2,col=2) 
lines(sun_k2[,1],sun_k2[,4],lty=3,col=3)
title(main=tit)
t1 <- "Chi-Square(2k)"
t2 <- "Bootstrap (Homo.)"
t3 <- "Bootstrap (Hetero.)"   
legend("topright",c(t1,t2,t3),lty=c(1,2,3),col=c(1,2,3))


x11()
xxlim <- range(ip_k2[,1])
yylim <- range(ip_k2[,(2:4)])
tit <- rbind("Figure 6: Industrial Production","Asymptotic and Bootstrap Distributions of F13");
plot(ip_k2[,1],ip_k2[,2],lty=1,col=1,xlim=xxlim,ylim=yylim,type="l",ann=0)
lines(ip_k2[,1],ip_k2[,3],lty=2,col=2) 
lines(ip_k2[,1],ip_k2[,4],lty=3,col=3)
title(main=tit)
t1 <- "Chi-Square(2k)"
t2 <- "Bootstrap (Homo.)"
t3 <- "Bootstrap (Hetero.)"   
legend("topright",c(t1,t2,t3),lty=c(1,2,3),col=c(1,2,3))


x11()
xxlim <- range(sun_k3[,1])
yylim <- range(sun_k3[,(2:4)])
tit <- rbind("Figure 7: Sunspot Series","Asymptotic and Bootstrap Distributions of F23");
plot(sun_k3[,1],sun_k3[,2],lty=1,col=1,xlim=xxlim,ylim=yylim,type="l",ann=0)
lines(sun_k3[,1],sun_k3[,3],lty=2,col=2) 
lines(sun_k3[,1],sun_k3[,4],lty=3,col=3)
lines(sun_k3[,1],sun_k3[,5],lty=4,col=4)
title(main=tit)
t1 <- "Chi-Square(k)"
t2 <- "Homoskedastic"
t3 <- "Regime Hetero."   
t4 <- "General Hetero."   
legend("topright",c(t1,t2,t3,t4),lty=c(1,2,3,4),col=c(1,2,3,4))


x11()
xxlim <- range(ip_k3[,1])
yylim <- range(ip_k3[,(2:4)])
tit <- rbind("Figure 8: Industrial Production","Asymptotic and Bootstrap Distributions of F23");
plot(ip_k3[,1],ip_k3[,2],lty=1,col=1,xlim=xxlim,ylim=yylim,type="l",ann=0)
lines(ip_k3[,1],ip_k3[,3],lty=2,col=2) 
lines(ip_k3[,1],ip_k3[,4],lty=3,col=3)
lines(ip_k3[,1],ip_k3[,5],lty=4,col=4)
title(main=tit)
t1 <- "Chi-Square(k)"
t2 <- "Homoskedastic"
t3 <- "Regime Hetero."   
t4 <- "General Hetero."   
legend("topright",c(t1,t2,t3,t4),lty=c(1,2,3,4),col=c(1,2,3,4))




